import {Component, OnInit} from '@angular/core';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';

/**
 * @title Highlight the first autocomplete option
 */
@Component({
  selector: 'autocomplete-auto-active-first-option-example',
  templateUrl: 'autocomplete-auto-active-first-option-example.html',
  styleUrls: ['autocomplete-auto-active-first-option-example.css'],
})
export class AutocompleteAutoActiveFirstOptionExample implements OnInit {
  myControl = new FormControl();
  options: string[] = ['Aurdino','Allocate','Action','Business','Building','Born','Calender','Chit-chat','Caution','Director','Doctor','Distributor','Excellent','Experience','Explain','Fast','Faster','Fastest','Gold','Green','Grass','Hacker','Hologram','history','Intellectual','Intelligent','Iterator','Internship','Justify','Join','Joking','Knowledge','Know','King','Live','Life','Lost','Most','Must','Memorable','No','None','Not','Out','Order','Once','Popular','People','Part','Punish','Quest','Quiz','Question','Random','Read','Rest','Smart','Sweet','Straight','Tough','Though','Through','Umbrella','Universe','Unfold','Various','Visit','Van','Word','Way','Ways','Wings','Xerox','Yes','Yet','Yen','Zebra','Zodiac','Zora','One', 'Two', 'Three'];
  filteredOptions: Observable<string[]>;

  ngOnInit() {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().indexOf(filterValue) === 0);
  }
}


/**  Copyright 2020 Google LLC. All Rights Reserved.
    Use of this source code is governed by an MIT-style license that
    can be found in the LICENSE file at http://angular.io/license */